//botoes menu
butJogo.addEventListener('click',()=>{
    window.location.href='jogo.html';
});
const butInicial = document.getElementById('butInicial');
butInicial.addEventListener('click',()=>{
    window.location.href='index.html';
});