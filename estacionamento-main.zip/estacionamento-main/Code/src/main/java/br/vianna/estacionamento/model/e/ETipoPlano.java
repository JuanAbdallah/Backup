package br.vianna.estacionamento.model.e;

public enum ETipoPlano {
    MENSAL, SEMANAL, DIARIA, HORA;
}
