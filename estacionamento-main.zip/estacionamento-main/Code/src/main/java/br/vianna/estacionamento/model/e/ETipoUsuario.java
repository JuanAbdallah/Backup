package br.vianna.estacionamento.model.e;

public enum ETipoUsuario {
    FUNCIONARIO, CLIENTE;
}
